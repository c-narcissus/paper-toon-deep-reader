# Paper Toon Deep Reader Skill v2.0.0

This package is a Clawhub/OpenClaw-friendly source skill for deep paper reading.

## What changed in v10

This version keeps the v9 `Research-Generative Paper Reading` lens and adds a new `Teaching-Explainer Paper Reading` lens without weakening any original requirement.

The skill now asks every paper reading report to do two things at once:

1. produce a rigorous, paper-grounded deep reading report; and
2. reverse-engineer how the paper could generate new research ideas; and
3. turn the deep read into material that helps the user explain, discuss, defend, and teach the paper to others.

## Core research-generative lens

Every report should identify:

```text
Paper = Important Setting
      + Broken Assumption
      + Borrowed Tool
      + New Constraint
      + Surrogate Mechanism
```

And should explicitly answer:

```text
What ideal mechanism Y is unavailable here?
What surrogate Z did the paper construct?
Which hidden assumption H_i makes Z fragile?
What new idea appears under not-H_i?
```

## Main files

- `SKILL.md`: main skill instructions.
- `schemas/detailed_report_contract.md`: authoritative report contract.
- `schemas/detailed_report_required_sections.json`: headings checked by validators.
- `schemas/research_generative_overlay.md`: full research-generative overlay.
- `workflow/`: staged reading workflow.
- `scripts/`: scaffold, validation, and bundle-building helpers.

## Recommended use

Upload this zip as the Paper Toon Deep Reader skill source. For each paper, generate one authoritative detailed report and run the validator before handoff.


## Core teaching-explainer lens

Every report should also produce:

```text
Before -> Pain -> Broken Assumption -> Key Replacement -> Mechanism -> Evidence -> Caveat -> Next Idea
```

And must include:

- audience map and teaching goal;
- 30-second / 3-minute / 10-minute summaries;
- formula, figure/table, and experiment teaching scripts;
- blackboard derivation and toy example;
- role-play discussion prompts;
- Q&A and defense bank;
- misunderstanding guardrails;
- slide/talk blueprint;
- three takeaways.

## New v10 files

- `schemas/teaching_explanation_overlay.md`
- `schemas/teaching_explanation_spec.template.json`
- `schemas/external_best_practices_sources.md`
- `schemas/reproducibility_defense_quality_overlay.md`
- `workflow/06_teaching_explainer_preparation.md`
- `workflow/07_talk_qa_rehearsal.md`


## Staged visual storyboard extension

After the complete text-only deep-reading report is delivered, this skill can continue with staged cartoon storyboard generation. The visual workflow is split into separate user-triggered steps: background/old-method defects, algorithm modules, experiments, limitations/defense, future directions, and presentation packaging.

Important constraints:

- The first skill run outputs only the plan, complete report, status, and next-step prompts; it must not generate images.
- Text report/status/prompt handoff and direct cartoon-image generation must not be mixed in the same assistant response.
- For ChatGPT web/app, every direct cartoon-image batch must use Create image. For Codex/Claude Code-style environments, use the `imagegen` skill first when available; otherwise use ChatGPT Images 2.0 API or another user-approved image-generation API.
- Do not generate SVG diagrams as a substitute for the requested cartoon-comic storyboard images. Do not use SVG, Mermaid, HTML/CSS, canvas, or manually drawn vector diagrams as the cartoon output.
- Storyboard image steps may be grounded in the uploaded PDF, LaTeX source, or both. If both exist, use PDF for rendered visual evidence and LaTeX for exact captions, labels, formulas, figure paths, and surrounding text.
- The default storyboard output is a continuous comic sequence made of multiple separate cartoon images/pages. It is not a single image, poster, or merged collage. If the user ambiguously asks to generate cartoons, treat it as a request for multiple continuous cartoon images.
- Multi-image prompt batches must include continuity and cinematography guidance: image order, camera/framing, transition logic, style bible, symbol bible, and consistency with prior batches.
- Direct generation should use small batches: usually 2-4 images per assistant reply. If a section needs more, split it across multiple replies while preserving continuity.
- Each cartoon page should stay low-density: one main teaching point, short labels, no crowded equation/table/module collage.
- Each cartoon page should use a single focal visual argument: one framing claim/question, one central diagram or scene, a few supporting callouts, and one takeaway/evidence note.
- Multi-image prompt batches must also be concise: before generation, remove redundant opening, setup, transition, recap, or repeated-motivation images. Each image needs a unique teaching contribution, and Step 1 should usually stay to 3-4 images.
- Image aspect ratio defaults to `9:16` phone portrait for mobile reading. Users can change it before image generation to `16:9`, `4:5`, `1:1`, `3:4`, or a custom ratio.
- Cartoon text/dialogue language defaults to Chinese. Character speech bubbles, narrator captions, page titles, labels, and recurring terms should remain in one language across batches unless the user changes it.
- Final PDF assembly combines approved cartoon pages and the Markdown deep-reading report into one PDF. Cartoon pages come first; the Markdown report is rendered after them. Use `scripts/assemble_storyboard_report_pdf.py` for this combined output.
- Page composition defaults to `single focal visual argument`, but the first reply should tell users they can switch to `process strip`, `split-screen comparison`, `defense Q&A card`, `minimal concept card`, or a reference-image-guided layout.
- Every text reply ends with the fallback prompt: `如果不知道下一步怎么问，可以说：使用这个skill，根据状态，告知下一步应该问什么。`
- Because sessions may be stateless, users should resume with prompts such as: `使用这个skill，根据状态，执行第2步：生成算法整体流程与各模块解释的连续卡通图。`


## v2.0.0 ClawHub packaging update

This package is prepared for ClawHub/OpenClaw publication under the slug `paper-toon-deep-reader`.

v2.0.0 makes page composition configurable. The default remains `single focal visual argument`, but the first text-only reply must tell users they can change the page composition mode. Supported options are `process strip`, `split-screen comparison`, `defense Q&A card`, `minimal concept card`, or `reference-guided`. The chosen mode is recorded as `Storyboard Page Composition` and preserved in the storyboard bible. All modes must remain low-density and single-purpose.

v2.0.0 also hardens modality and platform routing: report/text turns and direct cartoon-image generation turns must remain separate. ChatGPT web/app uses Create image for cartoon batches; Codex/coding-agent uses `imagegen` first, then ChatGPT Images 2.0 API, then another approved image API. SVG or vector substitutes are forbidden as cartoon output.

v10.1.16 adds the single-focal-visual-argument composition rule. Each page should use one dominant organizing visual, such as a mechanism map, risk map, comparison, loop, scene, or central metaphor. Supporting callouts may explain facets of that same visual thesis, but the page should not become a checklist-style poster or several mini-slides stacked together.

v10.1.15 adds low-density page and small-batch generation rules. Each cartoon image/page should carry only one main teaching point with short labels. Direct image-generation replies should normally produce 2-4 images; longer steps should be split across multiple replies/generation batches, with status tracking for completed and pending image numbers.

v10.1.14 changes the final PDF target from image-only to a combined handoff PDF: approved cartoon pages first, then the Markdown deep-reading report rendered as later PDF pages. It adds `scripts/assemble_storyboard_report_pdf.py` and updates `scripts/install_storyboard_pdf_deps.py` to install both Pillow and ReportLab for local Codex/coding-agent assembly. The older `scripts/assemble_storyboard_pdf.py` remains available for explicitly requested image-only PDFs.

v10.1.13 makes the multi-image comic requirement explicit as a hard rule. The normal storyboard deliverable is a continuous comic sequence made of multiple separate cartoon images/pages, never one standalone poster or merged collage. Ambiguous requests such as "生成卡通图" should be interpreted as "生成多张连续的卡通图". A single image is allowed only when explicitly requested as a lossy compact overview; it is not the recommended teaching or PDF-assembly output.

v10.1.12 adds a consistent cartoon text/dialogue language rule. The default is Chinese for character speech bubbles, narrator captions, page titles, short labels, and recurring terms; users may switch to English, bilingual Chinese-English, or another language before image generation. The selected language is recorded as `Storyboard Text Language` and preserved across later batches. Every text reply must also end with the fallback prompt for users who do not know what to ask next: `如果不知道下一步怎么问，可以说：使用这个skill，根据状态，告知下一步应该问什么。`

v10.1.11 changes the default storyboard aspect ratio to `9:16` phone portrait, because most users will browse cartoon explainer pages on phones. The first visual-preference handshake should mention that users can switch to `16:9` landscape slides, `4:5` feed posts, `1:1` square cards, `3:4` tablet/portrait handouts, or a custom ratio. Every status should record `Storyboard Aspect Ratio`. PDF assembly preserves the selected ratio; the local script now defaults to `1080x1920` and can be customized with `--page-width` / `--page-height`.

v10.1.10 adds redundancy pruning and minimum-sufficient storyboard planning. Multi-image generation remains the recommended mode, but the assistant must remove repeated opening/setup/transition/recap pages before prompt handoff or direct image generation. Each image must state its unique teaching contribution. Step 1 is tightened to 3-4 images by default: one hook/context image, one old-method failure image, one precise paper-problem/inspiration bridge, and one optional transition only when it adds new understanding.

v10.1.9 adds runtime-aware image/PDF routing and first-turn visual-preference setup. Status replies must record whether the workflow is running in ChatGPT web/app, Codex/coding-agent, or an unknown environment. ChatGPT web/app uses Create image; Codex/coding-agent prefers the `imagegen` skill, then ChatGPT Images 2.0 API, then another approved image API. Unknown environments should ask the user to clarify before image generation. Codex PDF assembly includes `scripts/install_storyboard_pdf_deps.py` plus the final assembly helpers. The first text-only reply should ask whether the user wants a cartoon style, reference images, scene, character count, roles, or traits; if not, use the default classroom setting.

v10.1.8 removes the fixed next-skill recommendation footer. Status replies should now focus on `Current Status` and `Possible User Inputs For Next Stage`. When suggesting how to continue cartoon generation, the prompt must explicitly tell the user to say `生成多张连续的卡通图`.

v10.1.7 adds a multi-image decomposition rule for storyboard generation. Each requested visual part should be split into several 16:9 cartoon images with one prompt per image and one main teaching point per image. The skill should not compress background, algorithm, experiments, limitations, and future directions into one crowded all-in-one picture.

v10.1.6 adds a source-grounding anti-hallucination check for storyboard image prompts and generated images. Before image generation, prompts must be checked against the original PDF/LaTeX and the authoritative deep-reading report; unsupported facts must be removed, marked `not reported`, or sent back to the user for evidence. After image generation, suspect images must be corrected before PDF assembly.

v10.1.5 adds a continuity / cinematography quality overlay for staged cartoon image prompts. Whenever the assistant writes prompts for multiple continuous cartoon images, each batch must preserve sequence order, camera movement, visual style, characters, symbols, data-flow direction, evidence labels, and narrative logic. Follow-up batches must continue the established storyboard bible from previous images.

v10.1.4 adds a reproducibility / defense / teaching quality overlay. Reports and storyboards must explain key concepts as intuition -> formula -> example -> limitation, expose module inputs/outputs/symbols/dimensions/parameters/data flow, separate paper-stated facts from inference, audit missing experimental details, and include a complete numeric training/inference walkthrough.

v10.1.3 removes `.clawhubignore` and `LICENSE` from the ClawHub upload zip because ClawHub may reject extensionless or dotfiles during its non-text-file check. The package still declares MIT-0 in metadata and documentation.

v10.1.2 supplements the coding-agent image-generation guidance: in Codex-style environments, prefer the `imagegen` skill when available; fall back to ChatGPT Images 2.0 API or another approved image-generation API only when needed.

### Staged cartoon storyboard + final PDF flow

The skill now supports a strict staged visual workflow:

0. First run: plan + complete text-only deep-reading report + status + next-step prompts. No images.
1. Background, old-method defects, paper problem, and inspiration storyboard.
2. Algorithm overview and module-by-module storyboard.
3. Experiment section storyboard.
4. Limitations and defense storyboard.
5. Future directions and innovation graph storyboard.
6. Cover, summary, and Q&A backup storyboard.
7. Final assembly: combine all approved storyboard images and the Markdown deep-reading report into one PDF. Cartoon pages come first; the report pages come after them. Default is 9:16 phone portrait.

### Platform notes

- ChatGPT web/app: use Create image for image generation.
- Codex / Claude Code / coding-agent environments: prefer the `imagegen` skill when available; otherwise use ChatGPT Images 2.0 API or another approved image-generation API.
- Do not use SVG diagrams as a replacement for cartoon-comic storyboard images.
- Default aspect ratio is 9:16 phone portrait; users may switch to 16:9, 4:5, 1:1, 3:4, or custom.
- Storyboard source basis can be PDF, LaTeX, or PDF+LaTeX; keep visual claims traceable to these sources or to the authoritative report derived from them.
- Each visual step should be split into multiple images by default. Do not compress a whole section into one dense collage unless the user explicitly asks for a single overview.
- Each direct generation reply should usually create only 2-4 images; longer sections continue in later replies with the same style and state.
- Each cartoon page should stay light enough to read on a phone: one main teaching point, short labels, and no crowded all-in-one formula/table/module page.
- Each cartoon page should have one dominant organizing visual. Supporting cards/callouts are fine only when they serve the same page-level visual thesis; independent mechanisms or steps should become separate pages.
- Each visual step should use the minimum sufficient number of images. If two images have the same teaching job, keep the clearer one and remove the other; generated redundant images should be dropped from the final PDF or regenerated.
- Prompt-only handoff and direct image generation both need a continuity/cinematography block for multi-image batches.
- Prompt-only handoff and direct image generation both need an anti-hallucination checklist against the original paper and authoritative report.
- The PDF assembly step uses existing images and the saved Markdown report only; use `scripts/assemble_storyboard_report_pdf.py` for the normal combined output. Use `scripts/assemble_storyboard_pdf.py` only for an explicitly requested image-only PDF.

### Resume prompt pattern

```text
使用这个skill，根据状态，执行第X步：<阶段名称>。
```

If unsure:

```text
使用这个skill，根据状态，告知下一步应该问什么。
```
