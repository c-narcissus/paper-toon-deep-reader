# Publishing to ClawHub

Skill slug: `paper-toon-deep-reader`
Version: `2.0.0`
License: `MIT-0`
Primary metadata source: `SKILL.md` YAML frontmatter

## Package contents

The package is a skill folder containing:

- `SKILL.md`
- `README.md`
- `_meta.json`
- `workflow/`
- `schemas/`
- `scripts/`
- publish-page and security notes

The upload zip intentionally excludes `.clawhubignore` and `LICENSE` because ClawHub may reject extensionless or dotfiles during non-text-file validation. MIT-0 remains declared in metadata and documentation.

## Recommended publish command

```bash
clawhub skill publish ./paper-toon-deep-reader --version 2.0.0
```

## Pre-publish checklist

- `SKILL.md` starts with YAML frontmatter containing `name`, `description`, and `version`.
- Folder name is lowercase and URL-safe: `paper-toon-deep-reader`.
- License is declared as MIT-0 in metadata and documentation.
- No generated images, PDFs, large binaries, or paper PDFs are included in the package.
- Optional helper scripts are transparent and local-only.
- Visual generation instructions clearly separate report generation, image generation, and final PDF assembly.
- Cartoon storyboard output is explicitly a continuous comic sequence made of multiple separate images/pages, not one standalone poster.
- Cartoon image pages are low-density: one main teaching point per page with short labels.
- Cartoon page composition defaults to single focal visual argument but is user-configurable in the first reply.
- `Storyboard Page Composition` is tracked in status and preserved in the storyboard bible.
- Direct image-generation replies normally produce 2-4 images; longer steps split across multiple batches.
- Final PDF assembly combines approved cartoon pages first and the Markdown deep-reading report after them.
- `scripts/assemble_storyboard_report_pdf.py` and `scripts/install_storyboard_pdf_deps.py` are included for local Codex/coding-agent PDF assembly.
- Cartoon storyboard instructions prune redundant opening/setup/transition/recap images and keep each image's teaching contribution distinct.
- Cartoon storyboard aspect ratio defaults to 9:16 phone portrait and remains user-adjustable before image generation.
- Cartoon text/dialogue language defaults to Chinese, remains consistent across batches, and is user-adjustable before image generation.
