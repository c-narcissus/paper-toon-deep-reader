# Cartoon Storyboard Continuity Quality Overlay

Use this overlay whenever a visual step writes image-generation prompts in text or directly generates several continuous cartoon images.

Modality and route contract: text/prompt/status turns and direct cartoon-image-generation turns must stay separate. If a turn writes prompts, continuity notes, source checks, or status, do not also generate images in that turn. For direct cartoon-image generation, ChatGPT web/app must use Create image; Codex/coding-agent must use the `imagegen` skill first when available, then ChatGPT Images 2.0 API, then another user-approved image-generation API. Never use SVG, Mermaid, HTML/CSS, canvas, or manually drawn vector diagrams as the cartoon-comic output or as a substitute for generated raster cartoon images.

## Core Rule

Treat each batch of cartoon images as one continuous short film and continuous comic sequence, not as isolated posters. Every prompt batch must preserve:

- story order;
- camera logic;
- visual style;
- character and narrator identity;
- symbol and metaphor dictionary;
- evidence-label design;
- text/dialogue language;
- data-flow direction;
- title/page numbering format.

If previous storyboard images already exist, the next batch must explicitly continue from them. Reuse the same style bible unless the user asks for a style reset.

Each visual part should be decomposed into multiple separate images/pages by default. Do not compress a whole section or several sections into one crowded infographic, one merged collage, or one standalone poster. A single image should carry one main teaching point; distinct ideas need distinct images. If the user ambiguously asks to generate cartoons, interpret the request as multiple continuous cartoon images. A single image is allowed only when the user explicitly asks for a compact overview; mark it as lossy and keep the multi-image comic sequence as the recommended output.

Low-density rule: one image/page should stay easy to read on a phone. Avoid dense paragraphs, full tables, multiple equations, too many arrows, or several independent takeaways on the same page. If an image prompt feels crowded, split the content into additional pages.

Configurable page-composition rule: the default is `single focal visual argument`, where one image/page is organized around one dominant visual thesis and one central diagram/scene. In the first text-only reply, tell the user this default and offer configurable alternatives: `process strip`, `split-screen comparison`, `defense Q&A card`, `minimal concept card`, or `reference-guided`. Supporting callouts are acceptable only when they explain facets of the same page-level purpose. Avoid checklist pages, multi-topic posters, and "several mini-slides glued together" compositions.

Small-batch rule: direct generation should normally create 2-4 images per assistant reply. If a section needs more than 4 images, generate it across multiple replies/batches and keep the same storyboard bible. Each status update should record completed and pending image numbers.

Use the minimum sufficient number of images. Multi-image does not mean maximum-image. Before writing prompts or generating images, remove images that only repeat an opening mood, motivation, transition, recap, or visual metaphor already handled by another image.

Default aspect ratio is `9:16` phone portrait. This makes the cartoon story easier to read on mobile screens. The user may change it before image generation to `16:9` landscape slides, `4:5` feed posts, `1:1` square cards, `3:4` tablet/portrait handouts, or a custom ratio. Once selected, preserve the aspect ratio in the storyboard bible and later batches unless the user asks to change it.

Default text/dialogue language is Chinese. Character speech bubbles, narrator captions, page titles, labels, and recurring terms should stay in the same language across a batch and later batches. The user may switch to English, bilingual Chinese-English, or another language; preserve that selected language thereafter. Do not mix Chinese and English casually except for necessary paper terms, formulas, dataset names, metric names, or a user-requested bilingual style.

## Prompt Block Required For Every Multi-Image Batch

Add a compact continuity block before the per-image prompts:

```text
Continuity / Cinematography Bible
- Aspect ratio: 9:16 phone portrait by default; use the user-selected ratio if specified.
- Decomposition: multiple separate images/pages for this section; one main teaching point per image; do not merge the whole section into one poster.
- Page composition: default `single focal visual argument` unless user selected another mode; record the chosen mode. Default structure is page title + framing claim/question + central diagram/scene + 2-5 supporting callouts + one takeaway/evidence note.
- Batch size: 2-4 images in this reply by default; longer sections continue in later batches.
- Redundancy pruning: every image has a unique teaching contribution; repeated setup, transition, or recap images have been removed.
- Style: academic cartoon-comic infographic, same line weight, palette, typography, panel border, title/footer.
- Text/dialogue language: Chinese by default; use the user-selected language if specified, and keep it consistent across speech bubbles, captions, labels, and titles.
- Narrator/protagonist: same appearance, expression range, outfit, and role.
- Symbol bible: repeated variables, model blocks, data icons, metric badges, warning labels, and evidence labels.
- Camera grammar: establish -> process -> close-up -> synthesis, adapted to the paper logic.
- Transition logic: each image states what it inherits from the previous image and what it prepares for the next image.
- Consistency with prior batches: preserve earlier character, palette, visual metaphors, arrows, numbering, and paper-specific icons.
```

Then each image prompt should include:

- `Image N / section name`;
- `sequence position`: total count, page/image number, and how this image fits the continuous comic sequence;
- `batch position`: current batch number, image numbers generated in this reply, and pending next-batch image numbers when relevant;
- `narrative role`: open / develop / turn / close / bridge;
- `teaching point`: the one idea assigned to this image;
- `page composition mode`: default single focal visual argument, or user-selected process strip / split-screen comparison / defense Q&A card / minimal concept card / reference-guided mode;
- `focal visual argument`: for the default mode, the central visual thesis and the dominant organizing diagram/scene; for other modes, the one page-level purpose that controls the layout;
- `unique contribution`: what the viewer learns here that no other image in the batch teaches;
- `do not merge`: which adjacent ideas are intentionally left to other images;
- `camera/framing`: wide, medium, close-up, top-down, split-screen, zoom-in, pan, cutaway, reveal, etc.;
- `content`: the exact scientific point to show;
- `continuity`: link to previous and next image;
- `evidence status`: paper-stated / reasonable inference / nearby-work inference / missing-not-reported;
- `text constraints`: short labels only, no dense paragraphs; language is Chinese by default and must remain consistent unless the user changed it.

## Choosing Camera Language

Use camera language to improve understanding:

- wide establishing shot: why the problem matters, data ecosystem, old-method failure context;
- medium shot: interaction between data, module, and learner/narrator;
- close-up: equation, tensor shape, module IO, metric definition, confusing table cell, or key exception;
- top-down map: full pipeline, dependency graph, experiment protocol, or baseline family;
- split-screen: old vs new method, training vs inference, paper-stated vs inferred, success vs failure case;
- cutaway: hidden module internals, missing implementation detail, or limitation;
- reveal: paper's central idea after motivation has been built;
- bridge shot: end one section and prepare the next visual step.

Do not use camera movement as decoration. The framing must help the viewer answer: "what should I understand now that I could not understand before?"

## Expression Suitability

A good cartoon explanation should be technically faithful and visually teachable:

- one main idea per image;
- low-density page: one main concept, short labels, no dense paragraphs, no all-in-one formula/table/module page;
- selected page-composition mode: default single focal visual argument, or user-selected process strip / split-screen comparison / defense Q&A card / minimal concept card / reference-guided composition;
- no matter which mode is selected, do not create a stacked checklist or multi-topic poster;
- multiple separate images/pages per section by default, forming a continuous comic sequence;
- small direct-generation batches: normally 2-4 images per assistant reply, with longer sections split across replies;
- minimum sufficient count, not a quota to maximize;
- no repeated opening, transition, recap, or motivation images unless each has a clearly different teaching contribution;
- no all-in-one dense collage for background + method + experiments + limitations;
- prerequisite first, conclusion later;
- stable left-to-right or top-to-bottom flow;
- repeated symbols for repeated concepts;
- labels short enough to read in a PDF slide;
- for `9:16` phone portrait, use shorter text, larger labels, and vertical composition; avoid tiny horizontal tables that only work on landscape slides;
- dialogue and label language consistent across images; default Chinese unless the user selected another language;
- equations shown only when they serve the explanation;
- charts/tables simplified without changing the factual result;
- missing values shown as `not reported` / `未报告`;
- uncertainty and inference categories visually distinct;
- no unsupported performance, hardware, runtime, or baseline claims;
- consistent margins, safe area, page numbers, and title bands for later PDF assembly.

## Redundancy Pruning And Minimum Sufficient Count

Before prompt handoff or direct image generation, run this pass:

1. Write a one-sentence unique contribution for each planned image.
2. Compare neighboring images and any images with the same narrative role.
3. Delete or merge images that mainly repeat the same motivation, old-method defect, setup context, transition, recap, metaphor, or emotional beat.
4. For Step 1, default to 3-4 images: one hook/context, one old-method failure, one precise paper-problem/inspiration bridge, and one optional transition only if it adds new understanding.
5. If a generated image is redundant after inspection, drop it from the PDF or regenerate the section with a tighter plan.

Do not solve redundancy by compressing many concepts into one crowded image. The correct balance is: separate distinct concepts, prune repeated concepts.

## Follow-Up Batch Rule

When generating later storyboard sections, first recover or restate:

- previous image count and section boundary;
- established narrator/protagonist;
- established color palette and typography;
- established recurring metaphors and icons;
- established text/dialogue language;
- established data-flow direction and evidence-label style;
- the last image's ending state.

Then design the next batch as a continuation. Avoid sudden switches in art style, camera grammar, arrow direction, narrator design, text/dialogue language, or symbol meanings unless the user explicitly requests a reset.

## Compression Guardrail

If a prompt tries to include more than one major teaching point, split it. Examples that should be separated:

- problem motivation vs old-method defects;
- symbol definitions vs model data flow;
- module internals vs training objective;
- training walkthrough vs inference walkthrough;
- dataset setup vs metric definitions;
- main results vs exception cases;
- limitations vs reviewer-defense answers;
- future directions vs already-validated claims.

The final PDF becomes clear because each page has a job. Do not trade readability for fewer images.

Also do not trade focus for more images. If two pages have the same job, keep the clearer page and remove the other.
