# Build Notes CN

- Source base: `paper_deep_reading_teaching_explainer_v10_visual_steps.zip`
- New package slug: `paper-toon-deep-reader`
- Version: `2.0.0`
- License: MIT-0
- Added final storyboard PDF assembly step and local helper script.
- Packaged as a ClawHub/OpenClaw text-based skill folder.
- Added configurable page-composition modes, with `single focal visual argument` as the default.
- Added explicit stage gates for report -> visual route/preferences -> raster cartoon batch -> review/next batch -> approved-image PDF assembly.
- Hardened image-routing rules: ChatGPT web/app uses Create image; Codex/coding-agent uses `imagegen` first, then ChatGPT Images 2.0 API, then another approved image API.
- Rejected SVG/vector substitutes for cartoon-comic storyboard output.
