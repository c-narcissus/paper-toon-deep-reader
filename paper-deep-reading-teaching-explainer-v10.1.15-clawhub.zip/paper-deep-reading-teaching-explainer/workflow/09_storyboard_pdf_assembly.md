# Workflow 09 — Final Storyboard + Markdown Report PDF Assembly

Use this workflow only after the user has approved all storyboard images from the staged visual workflow and the authoritative Markdown deep-reading report is available.

## Goal

Combine the final cartoon storyboard images and the Markdown deep-reading report into **one paginated PDF**:

1. cartoon/storyboard images first, in story order, one image per page;
2. Markdown deep-reading report second, rendered as readable text pages.

The default page shape remains `9:16` phone portrait for mobile reading. The user may choose `16:9`, `4:5`, `1:1`, `3:4`, or a custom ratio before assembly.

## Trigger prompts

Users may ask:

```text
使用这个skill，根据状态，执行最后一步：把所有已经生成的卡通图和Markdown精读报告合成一个PDF，卡通图在前面。
```

or:

```text
使用这个skill，根据状态，执行第7步：最终PDF合成，卡通图在前，Markdown精读报告在后。
```

## Inputs

Collect, in order:

1. image files from Step 1: background / defects / problem / inspiration;
2. image files from Step 2: algorithm overview and modules;
3. image files from Step 3: experiments;
4. image files from optional Step 4: limitations / defense;
5. image files from optional Step 5: future directions;
6. image files from optional Step 6: cover / summary / Q&A backup;
7. the authoritative Markdown deep-reading report file, usually a `.md` file saved from Step 0.

If filenames do not encode order, ask the user for the desired order or infer from visible titles such as `第1幕`, `第2幕`, ... and state the inferred order before assembly.

If the Markdown report exists only in the conversation, first save that exact report content as a `.md` file. Do not rewrite, shorten, or "improve" the report during PDF assembly.

## Rules

- Do **not** create new storyboard images in this step.
- Do **not** rewrite the full report in this step.
- The combined PDF order is mandatory: cartoon images first, Markdown report after the images.
- Preserve each image as a full page with the selected aspect ratio. Default: `9:16` phone portrait.
- Use one image per page unless the user explicitly asks for a contact sheet.
- Render the Markdown report after the images, preserving headings, bullets, code blocks, tables as readable text, and Chinese text.
- Add no extra watermarks or unrelated branding.
- If an image does not exactly match the target aspect ratio, fit it on the page without clipping; use white margins if needed.
- Verify the output by reopening or rendering the PDF when the environment supports verification.

## Recommended PDF output

```text
paper_storyboard_plus_deep_reading_report.pdf
paper_storyboard_images_report_and_pdf.zip   # optional handoff bundle
```

The older image-only helper output `paper_storyboard_all_images.pdf` is still acceptable only when the user explicitly asks for image-only assembly.

## ChatGPT web/app implementation guidance

Use the available file/Python/PDF workflow. A robust approach is:

1. collect image paths;
2. sort by stage and 幕 number;
3. collect or save the authoritative Markdown report as a `.md` file;
4. use PIL/Pillow to normalize each image and fit it onto a canvas with the selected aspect ratio; default canvas is `1080x1920`;
5. render Markdown report pages after all image pages;
6. save the image pages plus report pages as one PDF;
7. provide the PDF link and a short status note.

## Codex / Claude Code / coding-agent implementation guidance

Install dependencies first, then use `scripts/assemble_storyboard_report_pdf.py`.

Dependency setup:

```bash
python scripts/install_storyboard_pdf_deps.py
```

Default phone-portrait combined PDF:

```bash
python scripts/assemble_storyboard_report_pdf.py \
  --image-dir generated/storyboards/final_images \
  --report-md generated/reports/paper_deep_reading_report.md \
  --output generated/storyboards/paper_storyboard_plus_deep_reading_report.pdf
```

For a landscape slide deck PDF, override both image and report canvases:

```bash
python scripts/assemble_storyboard_report_pdf.py \
  --image-dir generated/storyboards/final_images \
  --report-md generated/reports/paper_deep_reading_report.md \
  --output generated/storyboards/paper_storyboard_plus_deep_reading_report.pdf \
  --image-page-width 1920 \
  --image-page-height 1080 \
  --report-page-width 1920 \
  --report-page-height 1080
```

Use the older `scripts/assemble_storyboard_pdf.py` only for an explicitly requested image-only PDF.

## Final response template

After assembly, reply briefly:

```text
已完成最终 PDF 合成：卡通图在前，Markdown 精读报告在后。

Current Status
- Runtime Environment: ChatGPT web/app | Codex / coding-agent | Unknown
- Image Generation Route: Create image | imagegen skill -> ChatGPT Images 2.0 API -> other approved API | Needs user clarification
- PDF Assembly Route: ChatGPT file/Python/PDF workflow | scripts/install_storyboard_pdf_deps.py + scripts/assemble_storyboard_report_pdf.py | Needs user clarification
- Storyboard Aspect Ratio: 9:16 phone portrait by default | user-selected custom ratio
- Storyboard Text Language: Chinese by default | user-selected language
- 已将 X 张图按第1幕 -> 第X幕顺序放在 PDF 前面。
- 已将 Markdown 精读报告渲染到图片页之后。
- 输出：paper_storyboard_plus_deep_reading_report.pdf

Possible User Inputs For Next Stage
- 使用这个skill，根据状态，检查PDF顺序、页面标题和报告分页是否正确。
- 使用这个skill，根据状态，打包所有图片、Markdown报告和最终PDF。
如果不知道下一步怎么问，可以说：`使用这个skill，根据状态，告知下一步应该问什么。`
```
