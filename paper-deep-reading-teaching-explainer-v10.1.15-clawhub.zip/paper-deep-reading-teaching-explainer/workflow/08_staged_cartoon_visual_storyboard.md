# Workflow 08 — Staged Cartoon Visual Storyboard Generation

This workflow is optional and starts **only after** the authoritative detailed report has been delivered.

## Separation rule

Text report and image generation must not happen in the same assistant turn.

- Step 0: text-only plan + complete deep-reading report + status + next-step prompts.
- Step 1+: one visual storyboard part per user request.
- Final assembly is a separate PDF-packaging step and must not generate new images; it combines approved cartoon pages first and the Markdown deep-reading report after them.

## Multi-image decomposition rule

Each visual part should be generated as a sequence of multiple `9:16` phone-portrait cartoon images by default, not compressed into a single overloaded image. The default output for a section is a coherent image batch with one prompt per image. The user may change the aspect ratio before image generation; common alternatives are `16:9` landscape slides, `4:5` feed posts, `1:1` square cards, `3:4` tablet/portrait handouts, or a custom ratio.

Hard rule: the storyboard deliverable is a continuous comic made of multiple separate cartoon images/pages. Do not answer a storyboard request with one standalone poster or one merged collage. If the user says only "生成卡通图" or "generate the cartoon", treat it as "生成多张连续的卡通图" / multiple continuous cartoon images. A single image is allowed only when the user explicitly asks for a single compact overview; label it as a lossy overview and recommend the normal multi-image sequence for teaching and PDF assembly.

## Small-batch generation rule

A cartoon image should not carry too much content. Each image/page should contain one main teaching point, one simple visual relation, and only short labels. If a page needs several equations, several modules, several datasets, a full table, or more than one independent takeaway, split it into more images.

When directly generating images, generate only a small batch per assistant reply:

- default: 2-4 images per reply;
- if a step needs 5-8 images, split it into two or more replies;
- after each batch, update `Current Status` with the step, batch number, generated image numbers, pending image numbers, and the next suggested user prompt;
- later batches must continue the same storyboard bible, style, characters, language, symbols, and camera logic.

Do not solve "too much content in one image" by making a larger collage. The correct response is to split the explanation into additional pages or additional generation batches.

Do not merge different visual parts into one image:

- background / old-method defects / motivation;
- algorithm overview;
- module internals and data flow;
- training and inference;
- experiments, metrics, baselines, and results;
- limitations and defense;
- future directions;
- cover, summary, and backup Q&A.

If the user asks for a single image, treat it as a compact overview only. State that the recommended mode remains a multi-image continuous comic sequence, because dense paper explanations need separate shots for readability, evidence checking, and later PDF assembly.

## Minimum-sufficient storyboard rule

Multi-image means "separate the genuinely different teaching moves", not "make as many images as possible". Before prompt handoff or direct image generation, run a redundancy-pruning pass:

- give every planned image a one-sentence `unique teaching contribution`;
- ask: "what new understanding does this image add that the neighboring images do not add?";
- ask: "is this single page too dense to read on a phone screen?";
- delete or merge images that mainly repeat the same motivation, old-method defect, transition, recap, metaphor, or emotional beat;
- be especially strict at the beginning: Step 1 should usually use 3-4 images, not a long chain of similar setup pages;
- keep extra opening images only when the paper has genuinely different motivation layers that require separate visual explanations.

If generated images later turn out redundant, do not assemble all of them into the PDF by default. Drop the redundant image or regenerate the section with a tighter prompt plan.

## Platform guidance

In a text-only planning/status turn before image generation, tell the user:

- ChatGPT 网页版 / App: use **Create image**.
- Do not generate SVG diagrams for the cartoon storyboard.
- Codex / Claude Code / coding-agent environments: prefer the `imagegen` skill when it is available. If `imagegen` is unavailable or insufficient, call **ChatGPT Images 2.0 API**. If that is also unavailable, use another user-approved image-generation API.
- If the environment is not clear, ask the user to confirm ChatGPT web/app versus Codex/coding-agent before image generation.
- Every `Current Status` must include `Runtime Environment`, `Image Generation Route`, `PDF Assembly Route`, `Storyboard Aspect Ratio`, `Storyboard Text Language`, and `Storyboard Batch` during visual generation.

## First visual-preference handshake

In the first text-only reply, ask whether the user wants to set cartoon style, aspect ratio, cartoon text/dialogue language, and story roles. Keep it optional:

- style options: `课堂板书漫画（默认）`, `扁平教育信息图`, `手绘白板草图`, `轻日漫科研课堂`, `柔和 3D 黏土/立体卡通`;
- aspect ratio options: default `9:16 手机竖屏 / phone portrait`, with optional user changes to `16:9 横版讲义/投影`, `4:5 社媒/信息流`, `1:1 方图`, `3:4 平板/竖版讲义`, or a custom ratio;
- text/dialogue language: default `中文`; all character speech bubbles, narrator captions, page titles, short labels, and recurring terms should stay in one consistent language unless the user explicitly chooses English, bilingual Chinese-English, or another language;
- the user may describe the style in text, or upload one or more reference images if the desired style is hard to describe;
- ask whether to set story scene, number of characters, roles, and character traits;
- if the user has no preference, use the default classroom scene: one teacher/narrator at the board plus 2-3 student/researcher listeners.

## Source basis for storyboard generation

Storyboard image generation can be based on **PDF**, **LaTeX source**, or both. Make this explicit in the planning/status text when relevant.

Use the following priority rules:

1. **PDF-only input**: use rendered pages, figure/table positions, visible diagrams, captions, axes, numeric tables, and nearby text.
2. **LaTeX-only input**: use `figure`/`table` environments, captions, labels, `\includegraphics` paths, equations, section text, appendix content, and source comments when useful.
3. **PDF + LaTeX input**: cross-check both; use the PDF for rendered visual appearance and LaTeX for exact captions, labels, formulas, figure filenames, and text around visuals.
4. **Authoritative report available**: treat the report as the storyboard's primary planning anchor, but preserve traceability back to PDF/LaTeX evidence.
5. **Conflict or missing detail**: do not invent; mark the item as “PDF/LaTeX 未报告” or ask the user for the missing source in a text-only turn.

Every storyboard step should state, internally or in a visible planning note, which source basis it is using: `PDF`, `LaTeX`, `PDF+LaTeX`, or `report-derived from PDF/LaTeX`.

When factual status matters, label content as one of:

- `paper-stated`
- `reasonable inference from this paper`
- `nearby-work inference`
- `missing / not reported`

## Visual source-grounding anti-hallucination check

Before writing image-generation prompts or directly generating images, check the planned visual content against the original paper sources and the authoritative detailed report.

Required checks:

- every module name, variable, formula, tensor shape, dataset, metric, baseline, numeric result, limitation, and claim in the prompt has a source in the PDF, LaTeX, or authoritative report;
- if a detail appears only in the report, verify that the report ties it back to the PDF/LaTeX evidence, or label it as report-derived inference;
- if the report conflicts with the original PDF/LaTeX, prefer the original paper and flag the conflict in a text-only note;
- if a detail is needed for the cartoon but not reported, write `未报告` / `not reported` or ask the user for the missing source; do not fill it in from memory;
- visual metaphors may simplify the idea, but must not imply unsupported causal relations, performance gains, hardware, runtime, baseline fairness, or data splits.

For text-only prompt handoff, include a short visible checklist:

```text
Anti-hallucination check:
- Original paper checked: yes
- Authoritative deep-reading report checked: yes
- Unsupported or missing facts: removed / marked not reported / needs user source
- Conflicts between paper and report: none / listed above
```

After images are generated, inspect them before accepting them into the storyboard sequence. Reject or revise images that introduce invented labels, wrong equations, unsupported numeric values, incorrect arrows/data flow, unreported hardware/runtime, ungrounded performance claims, or visual conclusions not supported by the paper/report. Do not assemble such images into the final PDF until corrected.

## Continuity and cinematography contract

Whenever the assistant writes image-generation prompts in text, or directly generates a continuous batch of multiple cartoon images, include a continuity/cinematography block. This applies to every visual step, not only the first one.

Required continuity fields:

- `sequence`: image number, section title, and whether this image opens, develops, turns, or closes the section;
- `batch`: current generation batch, image numbers in this reply, and pending next-batch image numbers when the section is longer than 4 images;
- `decomposition`: the single teaching point assigned to this image and why it should not be merged with adjacent images;
- `unique contribution`: what this image teaches that no other image in the same batch teaches;
- `camera`: establishing / wide / medium / close-up / top-down / split-screen / over-the-shoulder / zoom-in / pan / cutaway / reveal, chosen for the teaching purpose;
- `transition`: how this image connects to the previous and next image;
- `style bible`: narrator/protagonist, line style, color palette, typography, title/footer format, panel border style, aspect ratio, and text/dialogue language; default aspect ratio is `9:16` phone portrait and default text/dialogue language is Chinese unless the user changed them;
- `symbol bible`: repeated icons, variables, arrows, module blocks, data objects, metric badges, and evidence labels;
- `logic continuity`: what prerequisite the viewer should already know and what new idea this image adds.

For follow-up batches after earlier images exist, first restate the established storyboard bible and preserve it unless the user explicitly requests a style change. Later prompts must say how the new images continue the prior story, reuse the same narrator/visual metaphors/symbol dictionary, and avoid introducing a conflicting art style, color system, text/dialogue language, or data-flow direction.

Default camera rhythm for a section:

1. Establish the problem scene or section objective.
2. Move through process shots that show data flow or conceptual change.
3. Use close-ups for formulas, module internals, key table cells, or failure cases.
4. End with a synthesis shot that bridges to the next section.

## Visual expression suitability checklist

Before finalizing cartoon prompts, check whether the images will teach the idea rather than merely decorate it:

- one main teaching point per image;
- low-density page: one main concept, short labels, no dense paragraphs, no all-in-one formula/table/module page;
- a continuous comic sequence made of multiple separate images/pages, not one poster;
- multiple images per section by default, with separate prompts for distinct concepts;
- small direct-generation batches: normally 2-4 images per assistant reply; split longer steps across replies;
- minimum sufficient count: do not inflate the batch with repeated setup, transition, or recap images;
- unique contribution test: every image must add a new concept, evidence relation, example, limitation, or bridge that is not already handled by another image;
- opening discipline: for Step 1, usually keep one hook/context image, one old-method failure image, one precise paper-problem/inspiration bridge, and only one optional transition;
- no compressed all-in-one poster when the content contains several modules, datasets, metrics, limitations, or equations;
- clear visual hierarchy: title, central visual, labels, evidence status, and takeaway are easy to scan;
- readable labels: short phrases, no dense paragraphs, no tiny formula walls;
- stable spatial grammar: left-to-right or top-to-bottom flow, consistent arrow meanings, no crossed or ambiguous data-flow lines;
- recurring metaphor discipline: use the same metaphor for the same concept across all images, and do not introduce a cute scene that weakens technical precision;
- language consistency: use Chinese by default for dialogue, narration, page titles, and labels; keep the same language across all images in a batch and across follow-up batches, except necessary paper terms, formulas, dataset names, or explicit user-selected bilingual/English output;
- evidence honesty: paper facts, reasonable inferences, nearby-work inferences, and missing details remain visibly distinct;
- cognitive pacing: difficult equations or modules get a setup image before a close-up explanation;
- experiment clarity: charts/tables should highlight metric meaning, baseline source, exception cases, and reproduction risks rather than only showing winner/loser bars;
- accessibility: high contrast, color is not the only carrier of meaning, and text remains legible in the selected aspect ratio; for the default `9:16` phone portrait, use shorter labels, larger type, and stronger vertical hierarchy;
- PDF assembly readiness: consistent margins, page numbers, title band, and safe area so later PDF pages work as the front section of a combined PDF whose back section is the Markdown deep-reading report.

## Default visual steps

1. Background, old-method defects, paper problem, inspiration.
2. Algorithm overview and module-by-module flow: include symbols, input/output, dimensions, trainable parameters, fixed hyperparameters, data flow, training, inference, and a small numeric walkthrough where useful.
3. Experiment section: datasets, label definitions, splits, baseline provenance, whether baselines are rerun/reimplemented, metrics, results, exceptions, ablations, qualitative plots, and reproducibility gaps.
4. Limitations and defense / reviewer-QA visuals.
5. Future directions and innovation graph visuals.
6. Cover, summary, and Q&A backup visuals.
7. Final combined PDF assembly: combine all approved storyboard images and the Markdown deep-reading report into one PDF; cartoon pages come first, report pages come after them, and the selected aspect ratio is preserved by default. See `workflow/09_storyboard_pdf_assembly.md`.

## Step output expectations

For each visual step, generate a coherent set of cartoon-comic images in the selected aspect ratio; default is `9:16` phone portrait, unless the user changes it. Each batch should have:

- multiple images by default, one prompt per image;
- images/pages are ordered as one continuous comic sequence and should not be replaced by a single combined poster;
- each direct generation reply normally produces only 2-4 images; longer sections continue in later replies;
- consistent protagonist / narrator;
- consistent visual style, colors, icon language, panel numbering, and typography;
- consistent text/dialogue language; default Chinese unless the user changed it;
- clear continuity, camera progression, transitions, and left-to-right or top-to-bottom logic;
- paper-grounded data, equations, tables, or qualitative claims where relevant;
- knowledge dependency order: symbols before data, data before model, model before training/inference, training/inference before experiments;
- key concepts shown as intuition -> formula -> concrete example -> limitation when space permits;
- complex modules shown with inputs, outputs, symbols, dimensions, parameters, and data flow when available;
- missing experiment details shown explicitly as "not reported" rather than visually invented;
- no unsupported claims beyond the paper/report evidence;
- a redundancy-pruning pass that lists each image's unique teaching contribution and removes repeated motivation/setup/transition pages before generation;
- minimum sufficient image count, especially in Step 1 where 3-4 images is usually enough unless the paper needs distinct motivation layers;
- a compact continuity block in every prompt batch, especially when only text prompts are being handed to the user for later image generation;
- a source-grounding anti-hallucination checklist before prompt handoff and an image-inspection pass before PDF assembly;
- no attempt to pack a whole section into a single crowded collage.

## Stateless prompt reminder

At the end of every text reply, append this fallback prompt line as the final line:

`如果不知道下一步怎么问，可以说：使用这个skill，根据状态，告知下一步应该问什么。`

In text-only status turns that discuss continuation or recovery, also tell the user:

`如果开启新会话或上下文丢失，并且要继续生图，请说：使用这个skill，根据状态，执行第X步：生成多张连续的卡通图，内容是...。如果不知道下一步怎么问，可以说：使用这个skill，根据状态，告知下一步应该问什么。`
