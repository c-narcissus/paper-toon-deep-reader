#!/usr/bin/env python3
"""Assemble storyboard images and a Markdown deep-reading report into one PDF.

The output order is fixed for this skill:

1. approved cartoon/storyboard images, one image per page;
2. the Markdown deep-reading report rendered as text pages.

The default canvas is 1080x1920 phone portrait for both image and report pages.
Use --image-page-width/--image-page-height and --report-page-width/--report-page-height
when the user selected a different aspect ratio.
"""

from __future__ import annotations

import argparse
import io
import re
from pathlib import Path
from typing import Iterable, Iterator, List, Sequence, Tuple

try:
    from PIL import Image, ImageOps
    from reportlab.lib.colors import HexColor
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    from reportlab.pdfbase.pdfmetrics import stringWidth
    from reportlab.pdfgen import canvas
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "Pillow and reportlab are required. Run: "
        "python scripts/install_storyboard_pdf_deps.py"
    ) from exc


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"}
FONT_NAME = "STSong-Light"


def register_fonts() -> None:
    try:
        pdfmetrics.registerFont(UnicodeCIDFont(FONT_NAME))
    except Exception:
        # ReportLab keeps a global registry; repeated registration is harmless to skip.
        pass


def natural_key(path: Path):
    text = path.name.lower()
    nums = [
        int(n)
        for pair in re.findall(r"第\s*(\d+)\s*幕|(?:^|[_-])(\d+)(?:[_-]|\.)", text)
        for n in pair
        if n
    ]
    return (nums[0] if nums else 10**9, [int(s) if s.isdigit() else s for s in re.split(r"(\d+)", text)])


def collect_images(input_dir: Path, explicit: Iterable[str] | None = None) -> List[Path]:
    if explicit:
        paths = [Path(p) for p in explicit]
    else:
        paths = [p for p in input_dir.rglob("*") if p.suffix.lower() in IMAGE_EXTS]
    paths = [p for p in paths if p.exists() and p.is_file()]
    return sorted(paths, key=natural_key)


def image_reader(path: Path) -> Tuple[ImageReader, int, int]:
    with Image.open(path) as img:
        img = ImageOps.exif_transpose(img)
        if img.mode in {"RGBA", "LA"}:
            background = Image.new("RGB", img.size, (255, 255, 255))
            alpha = img.getchannel("A")
            background.paste(img.convert("RGBA"), mask=alpha)
            img = background
        else:
            img = img.convert("RGB")
        width, height = img.size
        buf = io.BytesIO()
        img.save(buf, format="PNG")
    buf.seek(0)
    return ImageReader(buf), width, height


def draw_image_page(pdf: canvas.Canvas, path: Path, page_size: Tuple[int, int]) -> None:
    page_w, page_h = page_size
    pdf.setPageSize(page_size)
    pdf.setFillColor(HexColor("#FFFFFF"))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    reader, img_w, img_h = image_reader(path)
    scale = min(page_w / img_w, page_h / img_h)
    draw_w = img_w * scale
    draw_h = img_h * scale
    x = (page_w - draw_w) / 2
    y = (page_h - draw_h) / 2
    pdf.drawImage(reader, x, y, width=draw_w, height=draw_h, mask="auto")
    pdf.showPage()


MarkdownBlock = Tuple[str, str]


def parse_markdown(lines: Sequence[str]) -> Iterator[MarkdownBlock]:
    i = 0
    while i < len(lines):
        raw = lines[i].rstrip("\n")
        stripped = raw.strip()
        if stripped.startswith("```"):
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i].rstrip("\n"))
                i += 1
            i += 1
            yield ("code", "\n".join(code_lines))
            continue
        if not stripped:
            yield ("blank", "")
            i += 1
            continue
        if re.match(r"#{1,6}\s+", stripped):
            yield ("heading", stripped)
            i += 1
            continue
        if re.match(r"^[-*_]{3,}$", stripped):
            yield ("rule", "")
            i += 1
            continue
        if re.match(r"^\s*([-*+]|\d+[.])\s+", raw):
            yield ("list", raw)
            i += 1
            continue
        if "|" in raw and raw.count("|") >= 2:
            yield ("table", raw)
            i += 1
            continue

        para = [stripped]
        i += 1
        while i < len(lines):
            nxt = lines[i].rstrip("\n")
            nxt_stripped = nxt.strip()
            if (
                not nxt_stripped
                or nxt_stripped.startswith("```")
                or re.match(r"#{1,6}\s+", nxt_stripped)
                or re.match(r"^\s*([-*+]|\d+[.])\s+", nxt)
                or ("|" in nxt and nxt.count("|") >= 2)
            ):
                break
            para.append(nxt_stripped)
            i += 1
        yield ("paragraph", " ".join(para))


class MarkdownReportRenderer:
    def __init__(self, pdf: canvas.Canvas, page_size: Tuple[int, int], title: str):
        self.pdf = pdf
        self.page_w, self.page_h = page_size
        self.margin_x = max(48, self.page_w * 0.07)
        self.margin_top = max(64, self.page_h * 0.06)
        self.margin_bottom = max(52, self.page_h * 0.055)
        self.content_w = self.page_w - 2 * self.margin_x
        self.body_size = max(12, min(20, self.page_w / 60))
        self.small_size = max(10, self.body_size * 0.82)
        self.y = 0.0
        self.page_no = 0
        self.title = title

    def new_page(self) -> None:
        if self.page_no:
            self.pdf.showPage()
        self.page_no += 1
        self.pdf.setPageSize((self.page_w, self.page_h))
        self.pdf.setFillColor(HexColor("#FFFFFF"))
        self.pdf.rect(0, 0, self.page_w, self.page_h, fill=1, stroke=0)
        self.y = self.page_h - self.margin_top
        self.pdf.setFillColor(HexColor("#555555"))
        self.pdf.setFont(FONT_NAME, self.small_size)
        self.pdf.drawRightString(self.page_w - self.margin_x, self.margin_bottom * 0.45, f"Report p.{self.page_no}")

    def ensure_space(self, needed: float) -> None:
        if self.y - needed < self.margin_bottom:
            self.new_page()

    def wrap(self, text: str, font_size: float, width: float) -> List[str]:
        chunks: List[str] = []
        current = ""
        for ch in text:
            candidate = current + ch
            if stringWidth(candidate, FONT_NAME, font_size) <= width or not current:
                current = candidate
            else:
                chunks.append(current.rstrip())
                current = ch.lstrip()
        if current:
            chunks.append(current.rstrip())
        return chunks or [""]

    def draw_wrapped(
        self,
        text: str,
        font_size: float | None = None,
        color: str = "#222222",
        indent: float = 0,
        leading: float | None = None,
    ) -> None:
        font_size = font_size or self.body_size
        leading = leading or font_size * 1.55
        width = self.content_w - indent
        self.pdf.setFont(FONT_NAME, font_size)
        self.pdf.setFillColor(HexColor(color))
        for line in self.wrap(text, font_size, width):
            self.ensure_space(leading)
            self.pdf.drawString(self.margin_x + indent, self.y, line)
            self.y -= leading

    def draw_heading(self, raw: str) -> None:
        level = len(raw) - len(raw.lstrip("#"))
        text = raw[level:].strip()
        size = {
            1: self.body_size * 1.65,
            2: self.body_size * 1.35,
            3: self.body_size * 1.18,
        }.get(level, self.body_size * 1.05)
        self.ensure_space(size * 2.2)
        self.y -= size * 0.35
        self.draw_wrapped(text, font_size=size, color="#111111", leading=size * 1.35)
        self.y -= size * 0.25

    def draw_rule(self) -> None:
        self.ensure_space(self.body_size * 2)
        self.pdf.setStrokeColor(HexColor("#DDDDDD"))
        self.pdf.line(self.margin_x, self.y, self.page_w - self.margin_x, self.y)
        self.y -= self.body_size

    def draw_code(self, text: str) -> None:
        for line in text.splitlines() or [""]:
            self.draw_wrapped("    " + line, font_size=self.small_size, color="#333333", leading=self.small_size * 1.45)
        self.y -= self.small_size * 0.5

    def render(self, markdown_text: str) -> None:
        self.new_page()
        self.draw_wrapped(self.title, font_size=self.body_size * 1.8, color="#111111", leading=self.body_size * 2.1)
        self.y -= self.body_size * 0.6
        self.draw_rule()
        for kind, text in parse_markdown(markdown_text.splitlines()):
            if kind == "blank":
                self.y -= self.body_size * 0.6
            elif kind == "heading":
                self.draw_heading(text)
            elif kind == "rule":
                self.draw_rule()
            elif kind == "list":
                self.draw_wrapped(text.strip(), indent=self.body_size * 1.2)
            elif kind == "table":
                self.draw_wrapped(text.strip(), font_size=self.small_size, color="#333333")
            elif kind == "code":
                self.draw_code(text)
            else:
                self.draw_wrapped(text)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Assemble storyboard images first and a Markdown deep-reading report second into one PDF."
    )
    parser.add_argument("--image-dir", type=Path, default=Path("."), help="Directory containing final storyboard images.")
    parser.add_argument("--report-md", type=Path, required=True, help="Markdown deep-reading report path.")
    parser.add_argument("--output", type=Path, required=True, help="Output combined PDF path.")
    parser.add_argument("images", nargs="*", help="Optional explicit image paths. If supplied, image-dir scan is skipped.")
    parser.add_argument("--image-page-width", type=int, default=1080, help="Image page width, default 1080 for 9:16.")
    parser.add_argument("--image-page-height", type=int, default=1920, help="Image page height, default 1920 for 9:16.")
    parser.add_argument("--report-page-width", type=int, default=None, help="Report page width. Defaults to image page width.")
    parser.add_argument("--report-page-height", type=int, default=None, help="Report page height. Defaults to image page height.")
    parser.add_argument("--report-title", default="Markdown Deep-Reading Report", help="Title shown before the Markdown report.")
    args = parser.parse_args()

    if not args.report_md.exists():
        raise SystemExit(f"Markdown report not found: {args.report_md}")

    images = collect_images(args.image_dir, args.images if args.images else None)
    if not images:
        raise SystemExit("No storyboard images found. Provide --image-dir or explicit image paths.")

    image_page_size = (args.image_page_width, args.image_page_height)
    report_page_size = (
        args.report_page_width or args.image_page_width,
        args.report_page_height or args.image_page_height,
    )
    report_text = args.report_md.read_text(encoding="utf-8")

    register_fonts()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(args.output))

    for path in images:
        draw_image_page(pdf, path, image_page_size)

    renderer = MarkdownReportRenderer(pdf, report_page_size, args.report_title)
    renderer.render(report_text)
    pdf.save()

    print(f"Wrote {args.output}")
    print(f"Storyboard image pages first: {len(images)}")
    print(f"Markdown report pages after images: {renderer.page_no}")
    for i, p in enumerate(images, 1):
        print(f"{i:02d}: {p}")
    print(f"Report: {args.report_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
