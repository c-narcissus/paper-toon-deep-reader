#!/usr/bin/env python3
"""Install local dependencies for storyboard and report PDF assembly.

Run from the skill root or project root before using
scripts/assemble_storyboard_pdf.py or scripts/assemble_storyboard_report_pdf.py
in Codex / coding-agent environments.
"""

from __future__ import annotations

import subprocess
import sys


REQUIRED_PACKAGES = ["Pillow>=10.0.0", "reportlab>=4.0.0"]


def main() -> int:
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *REQUIRED_PACKAGES]
    print("Installing storyboard + Markdown report PDF dependencies:")
    print(" ".join(cmd))
    subprocess.check_call(cmd)
    print("Done. You can now run:")
    print("- scripts/assemble_storyboard_pdf.py")
    print("- scripts/assemble_storyboard_report_pdf.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
