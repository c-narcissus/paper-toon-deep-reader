#!/usr/bin/env python3
"""Install local dependencies for storyboard PDF assembly.

Run from the skill root or project root before using
scripts/assemble_storyboard_pdf.py in Codex / coding-agent environments.
"""

from __future__ import annotations

import subprocess
import sys


REQUIRED_PACKAGES = ["Pillow>=10.0.0"]


def main() -> int:
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *REQUIRED_PACKAGES]
    print("Installing storyboard PDF dependencies:")
    print(" ".join(cmd))
    subprocess.check_call(cmd)
    print("Done. You can now run scripts/assemble_storyboard_pdf.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
