# Workflow 09 — Final Storyboard Image PDF Assembly

Use this workflow only after the user has approved all storyboard images from the staged visual workflow.

## Goal

Combine all final storyboard images into one paginated PDF that preserves the selected storyboard aspect ratio. The default is `9:16` phone portrait for mobile reading, but the user may choose `16:9`, `4:5`, `1:1`, `3:4`, or a custom ratio.

## Trigger prompts

Users may ask:

```text
使用这个skill，根据状态，执行最后一步：把所有已经生成的图合成一个PDF。
```

or:

```text
使用这个skill，根据状态，执行第7步：最终图片PDF合成。
```

## Inputs

Collect, in order:

1. image files from Step 1: background / defects / problem / inspiration;
2. image files from Step 2: algorithm overview and modules;
3. image files from Step 3: experiments;
4. image files from optional Step 4: limitations / defense;
5. image files from optional Step 5: future directions;
6. image files from optional Step 6: cover / summary / Q&A backup.

If filenames do not encode order, ask the user for the desired order or infer from visible titles such as `第1幕`, `第2幕`, ... and state the inferred order before assembly.

## Rules

- Do **not** create new storyboard images in this step.
- Do **not** rewrite the full report in this step.
- Preserve each image as a full page with the selected aspect ratio. Default: `9:16` phone portrait.
- Use one image per page unless the user explicitly asks for a contact sheet.
- Add no extra watermarks or unrelated branding.
- If an image does not exactly match the target aspect ratio, fit it on the page without clipping; use white margins if needed.
- Verify the output by reopening or rendering the PDF when the environment supports verification.

## Recommended PDF output

```text
paper_storyboard_all_images.pdf
paper_storyboard_images_and_pdf.zip   # optional handoff bundle
```

## ChatGPT web/app implementation guidance

Use the available file/Python/PDF workflow. A robust approach is:

1. collect image paths;
2. sort by stage and幕 number;
3. use PIL/Pillow to normalize orientation and fit each image onto a canvas with the selected aspect ratio; default canvas is `1080x1920`;
4. save all canvases as a single PDF;
5. provide the PDF link and a short status note.

## Codex / Claude Code / coding-agent implementation guidance

Install dependencies first, then use `scripts/assemble_storyboard_pdf.py`.

Dependency setup:

```bash
python scripts/install_storyboard_pdf_deps.py
```

Example:

```bash
python scripts/assemble_storyboard_pdf.py   --input-dir generated/storyboards/final_images   --output generated/storyboards/paper_storyboard_all_images.pdf
```

For a landscape slide deck PDF, override the default phone canvas:

```bash
python scripts/assemble_storyboard_pdf.py   --input-dir generated/storyboards/final_images   --output generated/storyboards/paper_storyboard_all_images.pdf   --page-width 1920   --page-height 1080
```

## Final response template

After assembly, reply briefly:

```text
已完成最终图片 PDF 合成。

Current Status
- Runtime Environment: ChatGPT web/app | Codex / coding-agent | Unknown
- Image Generation Route: Create image | imagegen skill -> ChatGPT Images 2.0 API -> other approved API | Needs user clarification
- PDF Assembly Route: ChatGPT file/Python/PDF workflow | scripts/install_storyboard_pdf_deps.py + scripts/assemble_storyboard_pdf.py | Needs user clarification
- Storyboard Aspect Ratio: 9:16 phone portrait by default | user-selected custom ratio
- Storyboard Text Language: Chinese by default | user-selected language
- 已将 X 张图按第1幕 -> 第X幕顺序合成为所选画幅的 PDF。
- 输出：paper_storyboard_all_images.pdf

Possible User Inputs For Next Stage
- 使用这个skill，根据状态，检查PDF顺序和页面标题是否正确。
- 使用这个skill，根据状态，生成PPT封面和答辩备用页。
如果不知道下一步怎么问，可以说：`使用这个skill，根据状态，告知下一步应该问什么。`
```
