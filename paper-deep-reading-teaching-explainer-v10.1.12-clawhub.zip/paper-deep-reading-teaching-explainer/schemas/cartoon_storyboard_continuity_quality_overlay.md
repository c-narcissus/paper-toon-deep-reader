# Cartoon Storyboard Continuity Quality Overlay

Use this overlay whenever a visual step writes image-generation prompts in text or directly generates several continuous cartoon images.

## Core Rule

Treat each batch of cartoon images as one continuous short film, not as isolated posters. Every prompt batch must preserve:

- story order;
- camera logic;
- visual style;
- character and narrator identity;
- symbol and metaphor dictionary;
- evidence-label design;
- text/dialogue language;
- data-flow direction;
- title/page numbering format.

If previous storyboard images already exist, the next batch must explicitly continue from them. Reuse the same style bible unless the user asks for a style reset.

Each visual part should be decomposed into multiple images by default. Do not compress a whole section or several sections into one crowded infographic. A single image should carry one main teaching point; distinct ideas need distinct images.

Use the minimum sufficient number of images. Multi-image does not mean maximum-image. Before writing prompts or generating images, remove images that only repeat an opening mood, motivation, transition, recap, or visual metaphor already handled by another image.

Default aspect ratio is `9:16` phone portrait. This makes the cartoon story easier to read on mobile screens. The user may change it before image generation to `16:9` landscape slides, `4:5` feed posts, `1:1` square cards, `3:4` tablet/portrait handouts, or a custom ratio. Once selected, preserve the aspect ratio in the storyboard bible and later batches unless the user asks to change it.

Default text/dialogue language is Chinese. Character speech bubbles, narrator captions, page titles, labels, and recurring terms should stay in the same language across a batch and later batches. The user may switch to English, bilingual Chinese-English, or another language; preserve that selected language thereafter. Do not mix Chinese and English casually except for necessary paper terms, formulas, dataset names, metric names, or a user-requested bilingual style.

## Prompt Block Required For Every Multi-Image Batch

Add a compact continuity block before the per-image prompts:

```text
Continuity / Cinematography Bible
- Aspect ratio: 9:16 phone portrait by default; use the user-selected ratio if specified.
- Decomposition: multiple images for this section; one main teaching point per image; do not merge the whole section into one poster.
- Redundancy pruning: every image has a unique teaching contribution; repeated setup, transition, or recap images have been removed.
- Style: academic cartoon-comic infographic, same line weight, palette, typography, panel border, title/footer.
- Text/dialogue language: Chinese by default; use the user-selected language if specified, and keep it consistent across speech bubbles, captions, labels, and titles.
- Narrator/protagonist: same appearance, expression range, outfit, and role.
- Symbol bible: repeated variables, model blocks, data icons, metric badges, warning labels, and evidence labels.
- Camera grammar: establish -> process -> close-up -> synthesis, adapted to the paper logic.
- Transition logic: each image states what it inherits from the previous image and what it prepares for the next image.
- Consistency with prior batches: preserve earlier character, palette, visual metaphors, arrows, numbering, and paper-specific icons.
```

Then each image prompt should include:

- `Image N / section name`;
- `narrative role`: open / develop / turn / close / bridge;
- `teaching point`: the one idea assigned to this image;
- `unique contribution`: what the viewer learns here that no other image in the batch teaches;
- `do not merge`: which adjacent ideas are intentionally left to other images;
- `camera/framing`: wide, medium, close-up, top-down, split-screen, zoom-in, pan, cutaway, reveal, etc.;
- `content`: the exact scientific point to show;
- `continuity`: link to previous and next image;
- `evidence status`: paper-stated / reasonable inference / nearby-work inference / missing-not-reported;
- `text constraints`: short labels only, no dense paragraphs; language is Chinese by default and must remain consistent unless the user changed it.

## Choosing Camera Language

Use camera language to improve understanding:

- wide establishing shot: why the problem matters, data ecosystem, old-method failure context;
- medium shot: interaction between data, module, and learner/narrator;
- close-up: equation, tensor shape, module IO, metric definition, confusing table cell, or key exception;
- top-down map: full pipeline, dependency graph, experiment protocol, or baseline family;
- split-screen: old vs new method, training vs inference, paper-stated vs inferred, success vs failure case;
- cutaway: hidden module internals, missing implementation detail, or limitation;
- reveal: paper's central idea after motivation has been built;
- bridge shot: end one section and prepare the next visual step.

Do not use camera movement as decoration. The framing must help the viewer answer: "what should I understand now that I could not understand before?"

## Expression Suitability

A good cartoon explanation should be technically faithful and visually teachable:

- one main idea per image;
- multiple images per section by default;
- minimum sufficient count, not a quota to maximize;
- no repeated opening, transition, recap, or motivation images unless each has a clearly different teaching contribution;
- no all-in-one dense collage for background + method + experiments + limitations;
- prerequisite first, conclusion later;
- stable left-to-right or top-to-bottom flow;
- repeated symbols for repeated concepts;
- labels short enough to read in a PDF slide;
- for `9:16` phone portrait, use shorter text, larger labels, and vertical composition; avoid tiny horizontal tables that only work on landscape slides;
- dialogue and label language consistent across images; default Chinese unless the user selected another language;
- equations shown only when they serve the explanation;
- charts/tables simplified without changing the factual result;
- missing values shown as `not reported` / `未报告`;
- uncertainty and inference categories visually distinct;
- no unsupported performance, hardware, runtime, or baseline claims;
- consistent margins, safe area, page numbers, and title bands for later PDF assembly.

## Redundancy Pruning And Minimum Sufficient Count

Before prompt handoff or direct image generation, run this pass:

1. Write a one-sentence unique contribution for each planned image.
2. Compare neighboring images and any images with the same narrative role.
3. Delete or merge images that mainly repeat the same motivation, old-method defect, setup context, transition, recap, metaphor, or emotional beat.
4. For Step 1, default to 3-4 images: one hook/context, one old-method failure, one precise paper-problem/inspiration bridge, and one optional transition only if it adds new understanding.
5. If a generated image is redundant after inspection, drop it from the PDF or regenerate the section with a tighter plan.

Do not solve redundancy by compressing many concepts into one crowded image. The correct balance is: separate distinct concepts, prune repeated concepts.

## Follow-Up Batch Rule

When generating later storyboard sections, first recover or restate:

- previous image count and section boundary;
- established narrator/protagonist;
- established color palette and typography;
- established recurring metaphors and icons;
- established text/dialogue language;
- established data-flow direction and evidence-label style;
- the last image's ending state.

Then design the next batch as a continuation. Avoid sudden switches in art style, camera grammar, arrow direction, narrator design, text/dialogue language, or symbol meanings unless the user explicitly requests a reset.

## Compression Guardrail

If a prompt tries to include more than one major teaching point, split it. Examples that should be separated:

- problem motivation vs old-method defects;
- symbol definitions vs model data flow;
- module internals vs training objective;
- training walkthrough vs inference walkthrough;
- dataset setup vs metric definitions;
- main results vs exception cases;
- limitations vs reviewer-defense answers;
- future directions vs already-validated claims.

The final PDF becomes clear because each page has a job. Do not trade readability for fewer images.

Also do not trade focus for more images. If two pages have the same job, keep the clearer page and remove the other.
