# ClawHub 发布页信息：paper-deep-reading-teaching-explainer v10.1.1

| Field | Value |
|---|---|
| Name / Slug | `paper-deep-reading-teaching-explainer` |
| Display name | Paper Deep Reading Teaching Explainer |
| Version | `10.1.1` |
| License | `MIT-0` |
| Emoji | 📚 |
| Category | Research / Education / Paper Reading / Visualization |
| Primary metadata source | `SKILL.md` YAML frontmatter |

## 一句话简介

把论文精读变成完整的中文权威报告、教学讲解材料、研究方向挖掘结果，以及分阶段统一风格卡通图与最终图片 PDF 合成流程。

## Short description / Summary

Deep-read research papers into authoritative teaching reports, innovation-mining artifacts, staged cartoon storyboard image workflows, and final 16:9 image-PDF assembly guidance.

## 适用场景

- 论文精读、组会汇报、课程讲解、答辩准备；
- 从论文中挖掘新研究方向和创新点；
- 把论文内容拆成连续、统一风格、逻辑清晰的卡通漫画式分镜；
- 将所有生成图最终合成为一个 PDF handoff。

## 核心功能

1. 首次启动时先给 plan，然后只生成完整精读报告；这一步不生图。
2. 报告后提供状态、产出和下一步可用提问方式。
3. 后续按阶段生成统一风格的连续卡通图：背景/缺陷、算法、实验、局限、未来方向、封面/总结等。
4. 生图阶段可以基于 PDF、LaTeX 源码，或二者结合；PDF 用于渲染视觉证据，LaTeX 用于精确 caption、label、公式、figure 路径和上下文。
5. 最后单独执行 PDF 合成步骤，把所有图按顺序合成为一个 16:9 PDF。
6. 每次状态回复都提醒用户如何在无状态会话中继续.

## 用户触发示例

```text
请使用这个skill精读这篇论文，直接显示完整报告。
```

```text
使用这个skill，根据状态，执行第1步：生成背景、旧方法缺陷、问题与灵感来源的连续卡通图。
```

```text
使用这个skill，根据状态，执行第2步：生成算法整体流程与各模块解释的连续卡通图。
```

```text
使用这个skill，根据状态，执行第3步：生成实验部分的连续卡通图。
```

```text
使用这个skill，根据状态，执行最后一步：把所有已经生成的图合成一个PDF。
```

```text
使用这个skill，根据状态，告知下一步应该问什么。
```

## 生图平台说明

- ChatGPT 网页版 / App：使用 Create image。
- Codex / Claude Code / coding-agent 环境：使用 ChatGPT Images 2.0 API 或其他用户批准的生图 API。
- 不要用 SVG 图替代用户要求的卡通漫画分镜。
- 文字报告和生图不能在同一次回答里混合。
- 生图可以基于 PDF 或 LaTeX 源码；若二者同时存在，应交叉核对。

## 最终 PDF 说明

最终 PDF 合成阶段只处理已经生成、已确认的图片，不再生成新图。推荐输出：

```text
paper_storyboard_all_images.pdf
paper_storyboard_images_and_pdf.zip
```

## Tags

`paper-reading`, `research`, `education`, `teaching`, `visual-storyboard`, `cartoon-infographic`, `image-prompt`, `pdf-assembly`, `deep-reading`, `clawhub`, `mit-0`

## Release notes

v10.1.1 在 v10.1.0 的 ClawHub 封装和最终图片 PDF 合成基础上，进一步明确：生图阶段可基于 PDF、LaTeX 源码，或二者结合进行证据对齐。
