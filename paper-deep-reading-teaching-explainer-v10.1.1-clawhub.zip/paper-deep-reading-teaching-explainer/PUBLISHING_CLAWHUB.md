# Publishing to ClawHub

Skill slug: `paper-deep-reading-teaching-explainer`
Version: `10.1.0`
License: `MIT-0`
Primary metadata source: `SKILL.md` YAML frontmatter

## Package contents

The package is a skill folder containing:

- `SKILL.md`
- `README.md`
- `LICENSE`
- `_meta.json`
- `.clawhubignore`
- `workflow/`
- `schemas/`
- `scripts/`
- publish-page and security notes

## Recommended publish command

```bash
clawhub skill publish ./paper-deep-reading-teaching-explainer --version 10.1.0
```

## Pre-publish checklist

- `SKILL.md` starts with YAML frontmatter containing `name`, `description`, and `version`.
- Folder name is lowercase and URL-safe: `paper-deep-reading-teaching-explainer`.
- License is MIT-0.
- No generated images, PDFs, large binaries, or paper PDFs are included in the package.
- Optional helper scripts are transparent and local-only.
- Visual generation instructions clearly separate report generation, image generation, and final PDF assembly.
